<?php
$db_url='127.0.0.1';
$db_user='root';
//$db_pwd="5lyz5wy4mi4hmlmhm3i131zx1hzhk3xxzxxxwhhm";
//$db_name='app_fj135790';
$db_port=3307;