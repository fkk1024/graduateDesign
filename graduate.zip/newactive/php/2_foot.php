<?php
header('Content-Type:text/html;charset=UTF-8');
?>
    <div class="container">
        <div class="row">
          <div class="col-md-6 col-xs-12">
            <div class="row">
              <div class="col-sm-6 col-xs-12 dt-footer-li">
                <h3>关于我们</h3>
                <ul class="list-unstyle">
                  <li><a href="#">关于我们</a></li>
                  <li><a href="#">加入我们</a></li>
                  <li><a href="#">联系我们</a></li>
                  <li><a href="#">商务合作</a></li>
                  <li><a href="#">帮助中心</a></li>
                  <li><a href="#">Marry Me收集工具</a></li>
                  <li><a href="#">标签集</a></li>
                  <li><a href="#">免责声明</a></li>
                </ul>
              </div>
              <div class="col-sm-6 col-xs-12 dt-footer-li">
                <h3>手机应用</h3>
                <ul class="list-unstyle">
                  <li><a href="#">Marry客户端</a></li>
                  <li><a href="#">Marry Me套餐</a></li>
                  <li><a href="#">精品壁纸</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-xs-12">
            <div class="row">
              <div class="col-sm-6 col-xs-12 dt-footer-li">
                <h3>关注我们</h3>
                <ul class="list-unstyle">
                  <li><a href="#">新浪微博</a></li>
                  <li><a href="#">腾讯微博</a></li>
                  <li><a href="#">人人网</a></li>
                  <li><a href="#">微信</a></li>
                  <li><a href="#">QQ空间</a></li>
                  <li><a href="#">豆瓣</a></li>
                </ul>
              </div>
              <div class="col-sm-6 col-xs-12 dt-footer-li">
                <h3>友情链接</h3>
                <ul class="list-unstyle">
                  <li><a href="#">爱物婚庆</a></li>
                  <li><a href="#">肉丁婚庆</a></li>
                  <li><a href="#">美食美酒婚庆</a></li>
                  <li><a href="#">传导体婚庆</a></li>
                  <li><a href="#">东方婚庆</a></li>
                  <li><a href="#">LADYMAX婚庆</a></li>
                  <li><a href="#">婚庆攻略</a></li>
                  <li><a href="#">更多..</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!--底部版权信息-->
        <div class="row dt-copy">
          <div class="col-md-6 col-xs-12">
            ©2017 fkk.com 版权所有。沪ICP备949894916号-3
          </div>
          <div class="col-md-6 col-xs-12">
            <div class="row dt-pic">
              <div class="col-sm-4 col-xs-12 dt-footer-c1">
                <a href="#"></a>
              </div>
              <div class="col-sm-4 col-xs-12 dt-footer-c2">
                <a href="#"></a>
              </div>
              <div class="col-sm-4 col-xs-12 dt-footer-c3">
                <a href="#"></a>
              </div>
            </div>
          </div>
        </div>
      </div>