<?php
header('Content-Type:text/html;charset=UTF-8');
?>
  <header>
			<div   class="container">
				<div   class="row bd">
					<div   class="col-md-8 col-xs-12">
						<ul class="list-inline pull-left ul_mar_cle">
							<li>
								<a href="">MM婚礼集团：</a>
							</li>
							<li>
								<a href="">兰摩婚纱</a>
							</li>
							<li>
								<a href="">小喜求婚</a>
							</li>
							<li>
								<a href="">77微电影</a>
							</li>
							<li>
								<a href="">Marry Me商学院</a>
							</li>
							<li>
								<a href="">MM-club高端婚礼定制</a>
							</li>
						</ul>
					</div>
					<div   class="col-md-4 col-xs-12">
						<ul class="list-inline pull-right  ul_mar_cle">
							<li>
								<a href="">客服热线：400-888-8888</a>
							</li>
							<li class="login_box" style="cursor: pointer;">
								<a href="../../login/login.html">登陆</a>
								<a href="login/login.html">注册</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!--面包屑导航条开始-->
			<div id="nav" class="navbar navbar-default">
				<div   class="container">
					<!--导航头部-->
					<div   class="navbar-header">
						<a href="../../index0.html" class="navbar-brand">Marry Me</a>
						<a href="#menu" data-toggle="collapse" class="navbar-toggle">
							<span   class="icon-bar"></span>
							<span   class="icon-bar"></span>
							<span   class="icon-bar"></span>
						</a>
					</div>
					<!--折叠部分-->
					<div id="menu" class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<li>
								<a href="../../index0.html">首页
									<p>HOME</p>
								</a>
							</li>
							<li>
								<a href="">婚礼案例
									<p>CASE</p>
								</a>
							</li>
							<li>
								<a href="#">服务团队
									<p>TEAM</p>
								</a>
							</li>
							<li>
								<a href="../../superiority/superiority.html">实力展示
									<p>SUPERIORITY</p>
								</a>
							</li>
							<li>
								<a href="../../activity/activity.html">最新活动
									<p>ACTIVITY</p>
								</a>
							</li>
							<li class="dropdown">
								<a href="../../news.html">
									婚礼资讯
									<p>CLASSROOM</p>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!--面包屑导航条结束-->
		</header>
		